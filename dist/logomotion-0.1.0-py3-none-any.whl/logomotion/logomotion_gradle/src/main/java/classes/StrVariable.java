package classes;

public class StrVariable implements Variable {
    public String value;

    public StrVariable(String value) {
        this.value = value;
    }
}
