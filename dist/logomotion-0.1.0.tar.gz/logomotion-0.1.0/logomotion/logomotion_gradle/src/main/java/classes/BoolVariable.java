package classes;

public class BoolVariable implements Variable {
    public boolean value;

    public BoolVariable(boolean value) {
        this.value = value;
    }
}
