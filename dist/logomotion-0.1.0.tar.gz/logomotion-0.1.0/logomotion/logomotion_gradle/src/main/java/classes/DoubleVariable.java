package classes;

public class DoubleVariable implements Variable {
    public double value;

    public DoubleVariable(double value) {
        this.value = value;
    }
}
