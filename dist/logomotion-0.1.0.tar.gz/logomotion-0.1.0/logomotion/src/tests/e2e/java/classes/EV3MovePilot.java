package classes;

public class EV3MovePilot {

    public EV3MovePilot() {
    }

    public void setSpeed(int speed) {
    }

    public void travel(double distance) {
    }

    public void rotate(double angle) {
    }
}
